using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AttaqueLiche : MonoBehaviour
{
    // Start is called before the first frame update
    public float cooldown =10;
    public float temps =0;
    public GameObject projectile;
    public bool is_attacking = true;
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        temps += Time.deltaTime;    
        if ( temps > cooldown ){
            temps = 0;
            if (is_attacking ){
                Attaque();
            }
        }
    }

    void Attaque(){
        var L = new[] {(5,5),(10,10), (-5,-5), (-10,-10), (5,-5),(10,-10),(-5,5),(-10,10) };
        for ( int i =0; i <8; i++ ){
            var vect = new Vector3(L[i].Item1,L[i].Item2,0);
            Instantiate(projectile, vect, transform.rotation);
            
        }
    }
}
